#include "GameEngineDriver.h"
#include "GameEngine.h"
#include "Global.h"

void testGameStates() {
    /*engine = new GameEngine();
    while(!engine->transition());*/
}

void testStartupPhase() {
    /*engine = new GameEngine();
    engine->startupPhase();

    cout << "\nPlayer Order:\n";
    for (Player *player : engine->players) {
        cout << *player;
    }*/
}

void testMainGameLoop() {
    /*engine = new GameEngine("test.txt");
    engine->startupPhase();
    engine->mainGameLoop();*/
}