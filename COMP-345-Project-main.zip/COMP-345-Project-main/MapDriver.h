#ifndef MAPDRIVER_H
#define MAPDRIVER_H

#include "Map.h"


void testLoadMaps();

Map* loadMap(string filePath);

#endif