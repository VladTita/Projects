#ifndef GAMEENGINEDRIVER_H
#define GAMEENGINEDRIVER_H

#include "GameEngine.h"
void testGameStates();
void testStartupPhase();
void testMainGameLoop();
#endif