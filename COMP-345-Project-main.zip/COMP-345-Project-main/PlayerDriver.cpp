#include "Player.h"
#include "PlayerDriver.h"
#include "Territory.h"
#include "Orders.h"
#include <string>

using namespace std;

void testPlayers()
{
    // SETUP
    // init new player
    /*Player newPlayer("player 1");

    // populating the defend territory list
    Territory defendTerritory("territory 1");
    newPlayer.addTerritory(&defendTerritory);
    vector<Territory*> toDefendList = newPlayer.getTerritories();
    newPlayer.toDefend(toDefendList);

    // populating the attack territory list
    Territory attackTerritory("territory 2");
    newPlayer.addTerritory(&attackTerritory);
    vector<Territory*> toAttackList = newPlayer.getTerritories();
    newPlayer.toAttack(toAttackList);

    // populating the order list
    newPlayer.issueOrder();

    Card *card = new Card();
    newPlayer.getHand()->addToHand(card);
    // OUTPUT
    for (Territory* t : newPlayer.getTerritories())
        cout << *t;
    cout << *newPlayer.getHand();*/
}
