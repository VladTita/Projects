#include "LoggingObserverDriver.h"
void testLoggingObserver() {

}