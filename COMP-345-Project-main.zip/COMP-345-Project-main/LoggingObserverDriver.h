#ifndef LOGGINGOBSERVERDRIVER_H
#define LOGGINGOBSERVERDRIVER_H

#include "LoggingObserver.h"
void testLoggingObserver();
#endif